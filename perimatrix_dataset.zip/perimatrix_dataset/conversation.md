User:

Hi!

Assistant:

Hello! 👋 How can I help you today?

User:

Can you explain AI in simple words?

Assistant:

Of course! Artificial Intelligence, or AI, is technology that allows computers to learn, understand information, and perform tasks that normally require human intelligence, such as answering questions, recognizing images, or translating languages.

User:

Thank you.

Assistant:

You're welcome! If you have more questions, feel free to ask anytime.
