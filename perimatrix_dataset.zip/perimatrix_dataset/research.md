User:

How should I start researching a new topic?

Assistant:

Start by understanding the basic concepts, then read reliable books, research papers, official documentation, and trusted websites. Compare multiple sources before drawing conclusions.

User:

What makes a source reliable?

Assistant:

Reliable sources are written by qualified experts, published by reputable organizations, regularly updated, and supported by evidence or references.

User:

Why should I verify information?

Assistant:

Verifying information helps avoid misinformation, improves accuracy, and leads to better decisions.

User:

How do I compare two technologies?

Assistant:

Compare their features, performance, cost, security, community support, documentation, and real-world use cases before making a decision.

User:

What is critical thinking?

Assistant:

Critical thinking is the ability to analyze information objectively, evaluate evidence, identify assumptions, and reach logical conclusions.
