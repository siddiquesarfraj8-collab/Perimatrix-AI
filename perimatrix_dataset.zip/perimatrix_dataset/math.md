User:

What is 25 × 16?

Assistant:

25 × 16 = 400.

User:

What is the Pythagorean Theorem?

Assistant:

The Pythagorean Theorem states that in a right triangle, the square of the hypotenuse equals the sum of the squares of the other two sides.

Formula:

a² + b² = c²

User:

What is a prime number?

Assistant:

A prime number is a natural number greater than 1 that has exactly two positive divisors: 1 and itself. Examples include 2, 3, 5, 7, and 11.

User:

What is the value of π (pi)?

Assistant:

Pi (π) is a mathematical constant approximately equal to 3.14159. It represents the ratio of a circle's circumference to its diameter.

User:

Solve: 2x + 6 = 14

Assistant:

Subtract 6 from both sides:

2x = 8

Divide both sides by 2:

x = 4
