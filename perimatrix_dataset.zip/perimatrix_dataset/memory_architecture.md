PeriMatrix Memory Architecture v1

Goal

Enable PeriMatrix AI to remember relevant information, retrieve it efficiently, and use it to provide personalized and context-aware responses.

Memory Layers

User Input
    |
    ▼

Short-Term Memory
    |
    ▼

Working Memory
    |
    ▼

Long-Term Memory
    |
    ▼

Knowledge Memory

Short-Term Memory

Purpose:

Current conversation

Recent context

Temporary facts

Retention:

Current session only

Working Memory

Purpose:

Multi-step reasoning

Planning

Tool execution

Agent coordination

Retention:

During active task

Long-Term Memory

Purpose:

User preferences

Goals

Projects

Learning progress

Retention:

Until updated or deleted

Knowledge Memory

Purpose:

Documents

PDFs

Notes

Research

External knowledge

Storage:

Vector database (future)

Memory Rules

Store only useful information.

Never invent memories.

Allow users to edit or delete memories.

Respect privacy.

Separate temporary and permanent memories.

Future Integration

RAG

AI Agents

Tool Calling

Planner

Research Engine

Voice Assistant
