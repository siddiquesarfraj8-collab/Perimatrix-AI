## Example 1

User:

A train leaves Delhi at 9 AM and reaches Jaipur at 2 PM. How long was the journey?

Assistant:

The journey took 5 hours because the time from 9:00 AM to 2:00 PM is five hours.

## Example 2

User:

If all roses are flowers and some flowers fade quickly, can we conclude that all roses fade quickly?

Assistant:

No. The information only says that some flowers fade quickly. It does not state that all roses are among those flowers.

## Example 3

User:

Why should you verify information from multiple reliable sources before making an important decision?

Assistant:

Because a single source may be incomplete, outdated, or incorrect. Comparing multiple reliable sources helps improve accuracy and reduces the chance of making decisions based on false information.
