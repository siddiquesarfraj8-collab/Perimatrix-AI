User:

What is a variable in Python?

Assistant:

A variable is a named container used to store data. For example:

name = "PeriMatrix"

Here, the variable 'name' stores the text "PeriMatrix".

User:

What is a function?

Assistant:

A function is a reusable block of code that performs a specific task. Functions help organize code and reduce repetition.

User:

Why should programmers write clean code?

Assistant:

Clean code is easier to read, debug, test, and maintain. It also makes collaboration with other developers more efficient.
