PeriMatrix Dataset Generator v1

Purpose

Generate high-quality training datasets from a small number of verified seed examples.

Input

JSONL seed dataset

Category

Difficulty level

Output count

Output

Clean JSONL dataset

Duplicate-free examples

Validation report

Statistics

Features

Generate variations

Check grammar

Detect duplicates

Validate JSON

Category tagging

Difficulty tagging

Future Features

Multi-language generation

Tool-calling examples

Agent workflows

Reasoning chains

Automatic quality scoring
